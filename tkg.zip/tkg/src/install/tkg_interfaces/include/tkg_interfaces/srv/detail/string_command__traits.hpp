// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from tkg_interfaces:srv/StringCommand.idl
// generated code does not contain a copyright notice

#ifndef TKG_INTERFACES__SRV__DETAIL__STRING_COMMAND__TRAITS_HPP_
#define TKG_INTERFACES__SRV__DETAIL__STRING_COMMAND__TRAITS_HPP_

#include "tkg_interfaces/srv/detail/string_command__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<tkg_interfaces::srv::StringCommand_Request>()
{
  return "tkg_interfaces::srv::StringCommand_Request";
}

template<>
inline const char * name<tkg_interfaces::srv::StringCommand_Request>()
{
  return "tkg_interfaces/srv/StringCommand_Request";
}

template<>
struct has_fixed_size<tkg_interfaces::srv::StringCommand_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<tkg_interfaces::srv::StringCommand_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<tkg_interfaces::srv::StringCommand_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<tkg_interfaces::srv::StringCommand_Response>()
{
  return "tkg_interfaces::srv::StringCommand_Response";
}

template<>
inline const char * name<tkg_interfaces::srv::StringCommand_Response>()
{
  return "tkg_interfaces/srv/StringCommand_Response";
}

template<>
struct has_fixed_size<tkg_interfaces::srv::StringCommand_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<tkg_interfaces::srv::StringCommand_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<tkg_interfaces::srv::StringCommand_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<tkg_interfaces::srv::StringCommand>()
{
  return "tkg_interfaces::srv::StringCommand";
}

template<>
inline const char * name<tkg_interfaces::srv::StringCommand>()
{
  return "tkg_interfaces/srv/StringCommand";
}

template<>
struct has_fixed_size<tkg_interfaces::srv::StringCommand>
  : std::integral_constant<
    bool,
    has_fixed_size<tkg_interfaces::srv::StringCommand_Request>::value &&
    has_fixed_size<tkg_interfaces::srv::StringCommand_Response>::value
  >
{
};

template<>
struct has_bounded_size<tkg_interfaces::srv::StringCommand>
  : std::integral_constant<
    bool,
    has_bounded_size<tkg_interfaces::srv::StringCommand_Request>::value &&
    has_bounded_size<tkg_interfaces::srv::StringCommand_Response>::value
  >
{
};

template<>
struct is_service<tkg_interfaces::srv::StringCommand>
  : std::true_type
{
};

template<>
struct is_service_request<tkg_interfaces::srv::StringCommand_Request>
  : std::true_type
{
};

template<>
struct is_service_response<tkg_interfaces::srv::StringCommand_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // TKG_INTERFACES__SRV__DETAIL__STRING_COMMAND__TRAITS_HPP_
