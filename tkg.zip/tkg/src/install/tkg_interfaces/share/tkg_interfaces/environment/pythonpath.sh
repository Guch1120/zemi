# generated from ament_package/template/environment_hook/pythonpath.sh.in

ament_prepend_unique_value PYTHONPATH "$AMENT_CURRENT_PREFIX/lib/python3.8/site-packages"
