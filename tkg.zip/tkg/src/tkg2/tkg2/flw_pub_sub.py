import sys
import rclpy
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from std_msgs.msg import String, Int32


class HappyPubSub(Node):
    def __init__(self):
        super().__init__('tkg_pub_sub')
        self.pub = self.create_publisher(String, 'tkg_msg', 'follow me')
        self.sub = self.create_subscription(Int32, 'number', self.callback,'follow me')
        self.happy_actions = ({
           'follow me': 'I will follow you'
            })

    def callback(self, sub_msg):
        pub_msg = String()
        self.get_logger().info(f'サブスクライブ:{sub_msg.data}')
        pub_msg.data = self.happy_actions[sub_msg.data % 10 + 1]
        self.pub.publish(pub_msg)
        self.get_logger().info(f'パブリッシュ:{pub_msg.data}')


def main():
    rclpy.init()
    node = HappyPubSub()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    except ExternalShutdownException:
        sys.exit(1)
    finally:
        rclpy.try_shutdown()
