from setuptools import setup

package_name = 'tkg2'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ubuntu',
    maintainer_email='ubuntu@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'tamago = tkg2.tamago:main',
            'syouyu = tkg2.syouyu:main',
            'tkg_node2 = tkg2.tkg_node2:main',
            'tkg_node3 = tkg2.tkg_node3:main',
            'tkg_publisher_node = tkg2.tkg_publisher_node:main',
            'tkg_subscriber_node = tkg2.tkg_subscriber_node:main',
            'tkg_pub_sub = tkg2.tkg_pub_sub:main',
            'flw_pub_sub = tkg2.flw_pub_sub:main'
        ],
    },
)

# colcon build
# source install/setup.bash
# source ~/tkg/install/setup.bash
# ros2 run tkg2 tkg_node2
