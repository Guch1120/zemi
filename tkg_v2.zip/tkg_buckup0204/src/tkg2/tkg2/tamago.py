def main():
    print('Hi from tkg2.')


if __name__ == '__main__':
    main()
