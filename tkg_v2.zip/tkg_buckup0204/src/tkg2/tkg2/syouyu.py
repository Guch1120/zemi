def main():
    print('Hi from tkg2_syouyu.')


if __name__ == '__main__':
    main()
