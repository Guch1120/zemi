// generated from rosidl_generator_c/resource/idl.h.em
// with input from tkg_interfaces:srv/StringCommand.idl
// generated code does not contain a copyright notice

#ifndef TKG_INTERFACES__SRV__STRING_COMMAND_H_
#define TKG_INTERFACES__SRV__STRING_COMMAND_H_

#include "tkg_interfaces/srv/detail/string_command__struct.h"
#include "tkg_interfaces/srv/detail/string_command__functions.h"
#include "tkg_interfaces/srv/detail/string_command__type_support.h"

#endif  // TKG_INTERFACES__SRV__STRING_COMMAND_H_
